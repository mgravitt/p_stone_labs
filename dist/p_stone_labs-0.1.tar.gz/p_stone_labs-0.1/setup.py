from setuptools import setup

setup(name='p_stone_labs',
      version='0.1',
      description='P-Stone Labs',
      url='http://github.com/gravitt8460',
      author='P-Stone',
      author_email='max.gravitt@gmail.com',
      license='MIT',
      packages=['p_stone_labs'],
      zip_safe=False)
